package com.registration.registration.repository;

import org.springframework.data.repository.CrudRepository;

import com.registration.registration.model.registrations;

public interface registrationsrepository extends CrudRepository<registrations, Integer>{

}
